package com.homfleet.utilites;

public class Dataconfigurevalidation 
{
	public final static String validateTologinsuccessfullmsg="Login Successfull";
	public final static String validateTotextmsg="Property";

}
